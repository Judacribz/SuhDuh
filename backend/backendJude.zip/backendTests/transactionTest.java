import static org.junit.Assert.*;
import junit.framework.JUnit4TestAdapter;
import org.junit.*;


public class transactionTest {

  @Before
  public void setup(){
    Backend b = new Backend();
  }

//runs a test to make sure transactions file was updated

  @Test
  public void allTest(){
    Transactions t = new Transactions();
    assertTrue(t.readFiles());
  }
}
