import static org.junit.Assert.*;
import junit.framework.JUnit4TestAdapter;
import org.junit.*;


public class updateAccountsTest {

//runs a test to make sure account file was updated

  @Test
  public void updateAccountsTest(){
    Accounts a = new Accounts();
    assertTrue(a.updateAccounts());
  }
}
