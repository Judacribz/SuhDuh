import static org.junit.Assert.*;
import junit.framework.JUnit4TestAdapter;
import org.junit.*;
import java.io.*;

//Test case for the method copyFile(file, file) within the class Backend
public class copyFileTest {

  File testText; //Initializing a test file with inputs
  File testCopy; //A test file to copy
  File dummy; //Dummy file to compare
  File dummy2;

  @Before
  public void setUp(){
    //Creating the files initialized above
    testText = new File("testText.txt");
    testCopy = new File("testCopy.txt");
    dummy = new File("dummy.txt");
    dummy2 = new File("dummy2.txt");
  }

  /*Test class for comparing a file that exists (in this case testText.txt)
		to a file we just created (testCopy.txt) */
  @Test
  public void copyFileTestFull2Empty(){
    Backend b = new Backend();
    System.out.println("\n\ncopyFile Full 2 Empty\n");
    /* We are asserting true that the method copyFile returns the boolean true.
	If it doesn't then the test fails and we will have to debug our backend */
    assertTrue(b.copyFile(testText, testCopy));
  }

  // Test class for comparing an empty file that we just created (dummy.txt) to a file that has data in it (testCopy.txt)
  @Test
  public void copyFileTestNULL2Full(){
    Backend b = new Backend();
    System.out.println("\n\ncopyFile NULL 2 Full\n");
    /*We are asserting that the method returns a boolean False, which implies the copying did not happen.
	If the boolean returns true, the test fails and we will have to debug our backend. */
    assertFalse(b.copyFile(dummy, testCopy));
  }
  
  //Test when we are trying to copy to empty files that we just created
  @Test
  public void copyFileTestNULL2NULL(){
    Backend b = new Backend();
    System.out.println("\n\ncopyFile NULL 2 NULL\n");
    /*We are asserting that the method copyFile returns a boolean False, which implies the copying did not happen.
	If the boolean returns true, the test fails and debugging the backend will be required. */
    assertFalse(b.copyFile(dummy, dummy2));
  }

}
