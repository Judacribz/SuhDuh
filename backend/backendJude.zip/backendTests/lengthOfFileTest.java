import static org.junit.Assert.*;
import junit.framework.JUnit4TestAdapter;
import org.junit.*;

//Test class to compare length of file
public class lengthOfFileTest {
  String test; //A new string test
  String dummy; //A dummy string to be tested

  @Before
  public void setUp(){
    //initializing both strings
    test = new String("testText.txt"); 
    dummy = new String ("dummy.txt");
  }

  //Test case for a non empty file
  @Test
  public void lengthOfFileTestFull(){
    Accounts a = new Accounts();
    
    /*Asserting true that the length of file after passing test is greater than 0 which is expected.
    If it is turns out to be false, the test fails and we have to debug our backend*/
    assertTrue(a.lengthOfFile(test) > 0);
  }

  //Test case for an empty file
  @Test
  public void lengthOfFileTestNULL(){
    Accounts a = new Accounts();
    /*Asserting false that the length of file after passing dummy is greater than 0 which is not expected.
    If it is turns out to be true, the test fails and we have to debug our backend*/
    assertFalse(a.lengthOfFile(dummy) > 0);
  }
}
