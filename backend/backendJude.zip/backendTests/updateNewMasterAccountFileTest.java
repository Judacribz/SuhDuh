import static org.junit.Assert.*;
import junit.framework.JUnit4TestAdapter;
import org.junit.*;


public class updateNewMasterAccountFileTest {
  String[] test1;
  String[] test2;
  String[] test3;

  @Before
  public void setUp(){
      test1 = new String[]{"05","         Admin", "00001", "000500.00", "MM"};
      test2 = new String[]{"04","         Admin", "00001", "000500.00", "MM"};
      test3 = new String[]{"04", "00001", "000500.00", "MM"};
  }

  //on new account creation
  @Test
  public void updateNewMasterAccountFileTestCreate(){
    Backend b = new Backend();
    assertTrue(b.updateNewMasterAccountFile(test1));
  }

  @Test
  public void updateNewMasterAccountFileTestRest(){
    Backend b = new Backend();
    assertTrue(b.updateNewMasterAccountFile(test2));
  }
  @Test
  public void updateNewMasterAccountFileTestFailure(){
    Backend b = new Backend();
    assertFalse(b.updateNewMasterAccountFile(test3));
  }

}
