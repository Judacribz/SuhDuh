import static org.junit.Assert.*;
import junit.framework.JUnit4TestAdapter;
import org.junit.*;


public class updateCurrentAccountsTest {

//runs a test to make sure current account file was updated

  @Test
  public void updateCurrentAccountsTest(){
    Accounts a = new Accounts();
    assertTrue(a.updateCurrentAccounts());
  }
}
