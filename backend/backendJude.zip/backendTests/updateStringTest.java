import static org.junit.Assert.*;
import junit.framework.JUnit4TestAdapter;
import org.junit.*;

public class updateStringTest
{

	String name;
	String update1;
	String update2;

	@Before
	public void setup()
	{
		name = new String("joseph");
		update1 = new String("joseph    ");
		update2 = new String("0joseph");
	}

    // Tests the first condition to see if string is formatted with spaces
	@Test
	public void updateStringTestSpace()
	{
		Backend b = new Backend();
		assertTrue(b.updateString(name, 10, " ").equals(update1));
	}

    // Tests the second condition to see if string is formatted with zeros
	@Test
	public void updateStringTestZero()
	{
		Backend b = new Backend();
		assertTrue(b.updateString(name, 7, "0").equals(update2));
	}

    // Tests the first condition to make sure it fails. String updated with
    // spaces and expected string has zeros.
	@Test
	public void updateStringTestSpaceFail()
	{
		Backend b = new Backend();
		assertFalse(b.updateString(name, 10, " ").equals(update2));
	}

    // Tests the first condition to make sure it fails. String updated with
    // zeros and expected string has spaces.
	@Test
	public void updateStringTestZeroFail()
	{
		Backend b = new Backend();
		assertFalse(b.updateString(name, 7, "0").equals(update1));
	}

    // Tests the first loop running it zero times.
    @Test
    public void updateStringSpaceFillLoopZeroTimes()
    {
        Backend b = new Backend();
        name = "1234567890";
        update1 = name;
        assertTrue(b.updateString(name, 10, " ").equals(update1));
    }

    // Tests the first loop running it one time.
    @Test
    public void updateStringSpaceFillLoopOneTimes()
    {
        Backend b = new Backend();
        name = "123456789";
        update1 = name + " ";
        assertTrue(b.updateString(name, 10, " ").equals(update1));
    }

    // Tests the first loop running it two times.
    @Test
    public void updateStringSpaceFillLoopTwoTimes()
    {
        Backend b = new Backend();
        name = "12345678";
        update1 = name + "  ";
        assertTrue(b.updateString(name, 10, " ").equals(update1));
    }

    // Tests the first loop running it many times.
    @Test
    public void updateStringSpaceFillLoopManyTimes()
    {
        Backend b = new Backend();
        name = "1";
        update1 = name + "         ";
        assertTrue(b.updateString(name, 10, " ").equals(update1));
    }

    // Tests the second loop running it zero times.
    @Test
    public void updateStringZeroFillLoopZeroTimes()
    {
        Backend b = new Backend();
        name = "1234567890";
        update2 = name;
        assertTrue(b.updateString(name, 10, "0").equals(update2));
    }

    // Tests the second loop running it one time.
    @Test
    public void updateStringZeroFillLoopOneTimes()
    {
        Backend b = new Backend();
        name = "123456789";
        update2 = "0" + name;
        assertTrue(b.updateString(name, 10, "0").equals(update2));
    }

    // Tests the second loop running it two times.
    @Test
    public void updateStringZeroFillLoopTwoTimes()
    {
        Backend b = new Backend();
        name = "12345678";
        update2 = "00" + name;
        assertTrue(b.updateString(name, 10, "0").equals(update2));
    }

    // Tests the second loop running it many times.
    @Test
    public void updateStringZeroFillLoopManyTimes()
    {
        Backend b = new Backend();
        name = "1";
        update2 = "000000000" + name;
        assertTrue(b.updateString(name, 10, "0").equals(update2));
    }
}
