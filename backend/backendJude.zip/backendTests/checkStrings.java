import static org.junit.Assert.*;
import junit.framework.JUnit4TestAdapter;
import org.junit.*;
import static org.hamcrest.CoreMatchers.*;

/* Test class to test checkString(string) method in the Backend class*/
public class checkStrings {

    @Before
    public void setup(){
        Backend b = new Backend(); //Creating a new backend
    }

    // Makes sure string array update is successful.
    @Test
    public void correctStringUpdate(){
         Backend b = new Backend();

        String[] str = new String[6]; //Creating the string of input files
        String[] strExp = new String[6]; //Creating a string of the expected output

        str[0] = "1";
        str[1] = "NAME";
        str[2] = "A";
        str[3] = "1.00";
        str[4] = "1";
        str[5] = "N";

        strExp[0] = "00001";
        strExp[1] = "NAME                ";
        strExp[2] = "A";   
        strExp[3] = "00001.00";
        strExp[4] = "0001";
        strExp[5] = "N";
        
        //asserting that the array of str equals the expected file, if the assertion fails, the test fails

        assertArrayEquals(b.checkStrings(str), strExp);
    }

    // Makes sure account number format is correct by using a false expectation.
    @Test
    public void incorrectAccountNumberUpdate(){
         Backend b = new Backend();

        String[] str = new String[6];
        String[] strNotExp = new String[6];

        str[0] = "1";
        str[1] = "NAME";
        str[2] = "A";
        str[3] = "1.00";
        str[4] = "1";
        str[5] = "N";

        strNotExp[0] = "0001"; // changed to 4 characters instead of 5
        strNotExp[1] = "NAME                ";
        strNotExp[2] = "A";
        strNotExp[3] = "00001.00";
        strNotExp[4] = "0001";
        strNotExp[5] = "N";
        
        /*Here we are asserting that the input file after getting called by the function and expected output
		are not equal. If they are equal, the test fails and we would have to debug our backend*/
		
        assertThat(b.checkStrings(str), not(strNotExp));
    }

    // Makes sure account name format is correct by using a false expectation.
    @Test
    public void incorrectAccountNameUpdate(){
         Backend b = new Backend();

        String[] str = new String[6];
        String[] strNotExp = new String[6];

        str[0] = "1";
        str[1] = "NAME";
        str[2] = "A";
        str[3] = "1.00";
        str[4] = "1";
        str[5] = "N";

        strNotExp[0] = "00001";
        strNotExp[1] = "NAME               "; // changed to 19 characters instead of 20
        strNotExp[2] = "A";
        strNotExp[3] = "00001.00";
        strNotExp[4] = "0001";
        strNotExp[5] = "N";
        
        /* Same as above, we assert that the string after function calling and the expected output aren't same. If they are,
		the test fails and we will have to debug the backend*/
        assertThat(b.checkStrings(str), not(strNotExp));
    }

    // Makes sure account balance format is correct by using a false expectation.
    @Test
    public void incorrectAccountBalanceUpdate(){
         Backend b = new Backend();

        String[] str = new String[6];
        String[] strNotExp = new String[6];

        str[0] = "1";
        str[1] = "NAME";
        str[2] = "A";
        str[3] = "1.00";
        str[4] = "1";
        str[5] = "N";

        strNotExp[0] = "00001";
        strNotExp[1] = "NAME                ";
        strNotExp[2] = "A";
        strNotExp[3] = "0001.00"; // changed to 7 characters instead of 8
        strNotExp[4] = "0001";
        strNotExp[5] = "N";
        
        /* Same as above, we assert that the string after function calling and the expected output aren't same. If they are,
		the test fails and we will have to debug the backend*/
        assertThat(b.checkStrings(str), not(strNotExp));
    }

    // Makes sure number of transactions  format is correct by using a false expectation.
    @Test
    public void incorrectAccountTxnsUpdate(){
         Backend b = new Backend();

        String[] str = new String[6];
        String[] strNotExp = new String[6];

        str[0] = "1";
        str[1] = "NAME";
        str[2] = "A";
        str[3] = "1.00";
        str[4] = "1";
        str[5] = "N";

        strNotExp[0] = "00001";
        strNotExp[1] = "NAME                ";
        strNotExp[2] = "A";
        strNotExp[3] = "00001.00";
        strNotExp[4] = "001"; // changed to 3 characters instead of 4
        strNotExp[5] = "N";

        /* Same as above, we assert that the string after function calling and the expected output aren't same. If they are,
		the test fails and we will have to debug the backend*/
        assertThat(b.checkStrings(str), not(strNotExp));
    }
}
