import static org.junit.Assert.*;
import junit.framework.JUnit4TestAdapter;
import org.junit.*;
import static org.hamcrest.CoreMatchers.*;

/*Test class to test checkString(string) method in the Backend class*/

public class checkStringsTest {

    @Before
    public void setup(){
        Backend b = new Backend(); //create backend
    }

    @Test

    public void correctStringUpdate(){
         Backend b = new Backend();

         //create strings input expected
        String[] str = new String[6];
        String[] strExp = new String[6];

        str[0] = "1";
        str[1] = "NAME";
        str[2] = "A";
        str[3] = "1.00";
        str[4] = "1";
        str[5] = "N";

        strExp[0] = "00001";
        strExp[1] = "NAME                ";
        strExp[2] = "A";
        strExp[3] = "00001.00";
        strExp[4] = "0001";
        strExp[5] = "N";

        //asserting that the array of str equals the expected file, if the assertion fails, the test fails


        assertArrayEquals(b.checkStrings(str), strExp);
    }

    //Test class for when incorrect account number has been provided
    @Test
    public void incorrectAccountNumberUpdate(){
         Backend b = new Backend();

        String[] str = new String[6];
        String[] strNotExp = new String[6];

        str[0] = "1";
        str[1] = "NAME";
        str[2] = "A";
        str[3] = "1.00";
        str[4] = "1";
        str[5] = "N";

        strNotExp[0] = "0001"; // changed to 4 characters instead of 5
        strNotExp[1] = "NAME                ";
        strNotExp[2] = "A";
        strNotExp[3] = "00001.00";
        strNotExp[4] = "0001";
        strNotExp[5] = "N";

        /*Here we are asserting that the input file after getting called by the function and expected output
		are not equal. If they are equal, the test fails and we would have to debug our backend*/
        assertThat(b.checkStrings(str), not(strNotExp));
    }

    //Test class for when incorrect account name has been provided
    @Test
    public void incorrectAccountNameUpdate(){
         Backend b = new Backend();

        String[] str = new String[6];
        String[] strNotExp = new String[6];

        str[0] = "1";
        str[1] = "NAME";
        str[2] = "A";
        str[3] = "1.00";
        str[4] = "1";
        str[5] = "N";

        strNotExp[0] = "00001";
        strNotExp[1] = "NAME               "; // changed to 19 characters instead of 20
        strNotExp[2] = "A";
        strNotExp[3] = "00001.00";
        strNotExp[4] = "0001";
        strNotExp[5] = "N";

        /* Same as above, we assert that the string after function calling and the expected output aren't same. If they are,
        		the test fails and we will have to debug the backend*/

        assertThat(b.checkStrings(str), not(strNotExp));
    }

     //Test case for when incorrect balance is provided
    @Test
    public void incorrectAccountBalanceUpdate(){
         Backend b = new Backend();

        String[] str = new String[6];
        String[] strNotExp = new String[6];

        str[0] = "1";
        str[1] = "NAME";
        str[2] = "A";
        str[3] = "1.00";
        str[4] = "1";
        str[5] = "N";

        strNotExp[0] = "00001";
        strNotExp[1] = "NAME                ";
        strNotExp[2] = "A";
        strNotExp[3] = "0001.00";
        strNotExp[4] = "0001";
        strNotExp[5] = "N";

        /* Same as above, we assert that the string after function calling and the expected output aren't same. If they are,
		the test fails and we will have to debug the backend*/

        assertThat(b.checkStrings(str), not(strNotExp));
    }

    //Test class when incorrect account transaction have been given
    @Test
    public void incorrectAccountTxnsUpdate(){
         Backend b = new Backend();

        String[] str = new String[6];
        String[] strNotExp = new String[6];

        str[0] = "1";
        str[1] = "NAME";
        str[2] = "A";
        str[3] = "1.00";
        str[4] = "1";
        str[5] = "N";

        strNotExp[0] = "00001";
        strNotExp[1] = "NAME                ";
        strNotExp[2] = "A";
        strNotExp[3] = "00001.00";
        strNotExp[4] = "001";
        strNotExp[5] = "N";

        /* Same as above, we assert that the string after function calling and the expected output aren't same. If they are,
    		the test fails and we will have to debug the backend*/
        assertThat(b.checkStrings(str), not(strNotExp));
    }
}
