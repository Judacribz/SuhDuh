/*
* Jude B, Asmy S, Robert de B
*(c) 2016 SomethingGreat
*backend.java
*/
import java.io.*;
import java.util.*;
import static java.nio.file.StandardCopyOption.*;
import static java.nio.channels.FileChannel.*;
import static java.nio.file.StandardOpenOption.*;

/*
* Backend.class
*This holds some key functions for the backend of the system.
*methods for copying files, string specifications, and updating files
*/
class Backend{

    public static String currPath = System.getProperty("user.dir");
    public static File path = new File(currPath);

    // Transactions found in this path
    public static String transPath = path.getAbsoluteFile().getParent() + "/rapid/";
    public static File curr = new File(currPath + "/acc.txt");
    public static File currAccFile = new File(currPath + "/CurrentAccounts.txt");
    public static File mastAccFile = new File(currPath + "/MasterAccounts.txt");
    public static File mastTxnFile = new File(currPath + "/_masterTransctionFile.txt");

    public static void main(String[] args){
        //TODO: create and run classes

        Transactions t = new Transactions();
        t.readFiles();

        Accounts A = new Accounts();

        A.updateAccounts();
        A.updateCurrentAccounts();
    }


    public boolean copyFile(File source, File dest){
    try {
           dest.createNewFile();


        InputStream is = null;
        OutputStream os = null;


        is = new FileInputStream(source);
        os = new FileOutputStream(dest, false);
        byte[] buffer = new byte[1024];
        int length;
        while ((length = is.read(buffer)) > 0) {
            os.write(buffer, 0, length);
        }
        is.close();
        os.close();

        } catch(Exception e) {
            System.out.println("Copy Error");
            return false;
        }
        return true;

    }



    // updates master account file based on a single string passed in
    // containing transaction information.
    public boolean updateNewMasterAccountFile(String[] part) {
        String[] sLine = new String[6];
        int count     = 0;
        int i         = 0;
        double bal    = 0;

        String line   = "";
        File mastOldAccFile = new File(currPath + "/OldMasterAccounts.txt");
        File tempFile       = new File(currPath + "/temp.txt");
        copyFile(mastAccFile, mastOldAccFile);

        if (part.length != 5) {
            return false;
        }

        // adds new account to master account file if trans code is 04
        if (part[0].equals("05")) {
                    try {
                        String name = part[1];
                        i = name.length();
                        for (int j = 0; j < 20-i; j++) {
                            name += " ";
                        }
                        part[1] = name;

                        String filename = currPath + "/MasterAccounts.txt";

                        FileWriter fw = new FileWriter(filename,true); //the true will append the new data
                        fw.write(part[2] + " " + part[1] + " A " + part[3] + " 0000 N");//appends the string to the file
                        fw.close();

                    } catch(IOException ioe) {
                        System.err.println("IOException: " + ioe.getMessage());
                        return false;
                    }
            return true;
        }



        try {
            copyFile(mastAccFile, tempFile);

            FileReader fileReader = new FileReader(tempFile);
            BufferedReader bufferedReader = new BufferedReader(fileReader);
            PrintWriter fileOut = new PrintWriter(currPath + "/MasterAccounts.txt", "UTF-8");
            while ((line = bufferedReader.readLine()) != null) {
                String[] temp = line.split(" +");
                sLine = temp;
                if (temp[3].equals(part[2]))
                {
                    if (part[0].equals(00)) {
                        sLine[4] = temp[4];
                    } else {
                        // increase count for txns and convert back to string
                        count = Integer.parseInt(temp[4]);
                        count++;
                        sLine[4] = Integer.toString(count);
                        i = (int)(Math.log10(count)+1);

                        for (i=0; i < 4; i++) {
                            sLine[4] = "0" + sLine[4];
                        }
                    }


                    switch (part[0]) {
                    case "01":
                    case "03":
                        bal = Double.parseDouble(temp[3]);
                        bal       -= Double.parseDouble(part[3]);

                        sLine[3] = String.valueOf(bal);
                        i = (int)(Math.log10(bal)+1);
                        break;
                    case "02":
                    case "04":
                        bal = Double.parseDouble(temp[3]);
                        bal       += Double.parseDouble(part[3]);

                        sLine[3] = String.valueOf(bal);
                        i = (int)(Math.log10(bal)+1);
                        break;
                    case "06": // does not write account to Master if delete
                        continue;
                    case "07":
                        sLine[2] = "D";
                        break;
                    case "08":
                        if (temp[5].equals("N")) {
                            sLine[5] = "S";
                        } else {
                            sLine[5] = "N";
                        }
                        break;
                    default:
                        break;
                    }
                }

                if (!sLine[1].equals("END")) {
                    sLine = checkStrings(sLine);
                }


                fileOut.println(sLine[0] + " " + sLine[1] + " " + sLine[2] + " " + sLine[3] + " " + sLine[4] + " " + sLine[5]);
            }

            fileOut.close();
            bufferedReader.close();
        } catch(FileNotFoundException ex) {
            System.out.println("Unable to open file '" + mastTxnFile + "'");
            return false;
        } catch(IOException ex) {
            System.out.println("Error reading file '" + mastTxnFile + "'");
            return false;
        }
        return true;
    }

    String[] checkStrings(String[] str) {

        int size = 0;
        String fill = "";

        for (int i = 0; i < str.length; i++) {
            switch (i) {
                case 0:
                    size = 5;
                    fill = "0";
                    break;
                case 3:
                    size = 8;
                    fill = "0";
                    break;
                case 4:
                    size = 4;
                    fill = "0";
                    break;
                case 1:
                    size = 20;
                    fill = " ";
                    break;
                default:
                    fill = "";
                    break;
            }

            if (i != 2 && i != 5) {
                str[i] = updateString(str[i], size, fill);
            }
        }

        return str;
    }

    String updateString(String str, int size, String fill) {
        String name = str;
        int i = name.length();
        if (fill.equals(" ")) {
            for (int j = 0; j < size-i; j++) {
                name += fill;
            }
        } else if (fill.equals("0")) {
            for (int j = 0; j < size-i; j++) {
                name = fill + name;
            }
        }

        return name;
    }

}

/*
*Accounts.class
*This class is used for updating the account files
*
*/
class Accounts {
    Backend B = new Backend();
    public static String currPath = System.getProperty("user.dir");
    public static File path = new File(currPath);

    // Transactions found in this path
    public static String transPath = path.getAbsoluteFile().getParent() + "/rapid/";

    public static File currAccFile = new File(currPath + "/CurrentAccounts.txt");
    public static File mastAccFile = new File(currPath + "/MasterAccounts.txt");
    public static File mastTxnFile = new File(currPath + "/_masterTransctionFile.txt");

    // Writes to current Account file based on Master account file
    boolean updateCurrentAccounts() {

        try {
            String line = "";
            FileReader fileReader = new FileReader(mastAccFile);
            BufferedReader bufferedReader = new BufferedReader(fileReader);
            PrintWriter fileOut = new PrintWriter(currPath + "/CurrentAccounts.txt", "UTF-8");

            while ((line = bufferedReader.readLine()) != null) {
                String [] part = line.split(" ");
                if (part[0].equals("99999")) {
                    break;
                }
                String half1 = line.substring(0, 38);
                String half2 = line.substring(43, 44);

                line = half1 + half2;

                fileOut.println(line);
            }

            fileOut.close();
            bufferedReader.close();
        } catch(FileNotFoundException ex) {
            System.out.println("Unable to open file '" + mastTxnFile + "'");
            return false;
        } catch(IOException ex) {
            System.out.println("Error reading file '" + mastTxnFile + "'");
            return false;
        }
        return true;
    }


    // reads in master txn file and updates master account file
    boolean updateAccounts() {
        try {
            String line = "";
            FileReader fileReader = new FileReader(mastTxnFile);
            BufferedReader bufferedReader = new BufferedReader(fileReader);

            while ((line = bufferedReader.readLine()) != null) {
                if (line.equals("")) {
                    continue;
                }

                String[] part = line.split(" +");

                if (part.length != 5) {
                    continue;
                }

                // get account number
                String txnType = part[0];
                // get account namer
                String accountName = part[1];

                // get account number
                String accountNumber = part[2];

                // get account current balance
                String currentBalance = part[3];

                // get miscs
                String misc = part[4];

                B.updateNewMasterAccountFile(part);
            }

            // Always close files.
            bufferedReader.close();
        } catch(FileNotFoundException ex) {
            System.out.println("Unable to open file '" + mastTxnFile + "'");
            return false;
        } catch(IOException ex) {
            System.out.println("Error reading file '" + mastTxnFile + "'");
            return false;
        }
        return true;
    }


    int lengthOfFile(String fileName) {

        int lineNum = 0;

        try (LineNumberReader lnr = new LineNumberReader(new FileReader(new File (fileName)))) {


            lnr.skip(Long.MAX_VALUE);
            System.out.println(lnr.getLineNumber() + 1);

            lineNum = lnr.getLineNumber() + 1;
            lnr.close();
        } catch(FileNotFoundException ex) {
            System.out.println(
                "Unable to open file '" +
                fileName + "'");
        }
        catch(IOException ex) {
            System.out.println(
                "Error reading file '"
                + fileName + "'");
            // Or we could just do this:
            // ex.printStackTrace();
        }


        return lineNum;
    }
}

/*
*Transactions.class
*This class is used for updating the transaction files
*
*/
class Transactions{
      //append master file
      public boolean readFiles(){
      //file io
      //File loadFile = new file;
      File currentFile;
      FileInputStream master = null;
      FileInputStream reader = null;
      FileOutputStream out = null;
      String frontendDest = (System.getProperty("user.dir"));

      File newDir;
      String masterFileName = "_masterTransctionFile.txt";

      //buffered reader for readinf
      BufferedReader transactionReader;
      File mergedTransactions = new File(masterFileName);


      try{
        //settin up in the initial directory
        File loadFile = new File(System.getProperty("user.dir")).getParentFile();
        System.out.println(loadFile);
        //navigating to the directory where the transaction files are
        newDir = new File(loadFile + "/rapid/");
        System.out.println("\n");


        //spitting out the contents of the new directory.
        try{
          // for loop to open each new transaction file
          // for for(j in number of transfiles)
          //get filename
          System.out.println(newDir.getCanonicalPath());
          File[] filesf = newDir.listFiles();
          for(int j = 0; j < filesf.length; j++){
            //getting the appropriate files
            if(filesf[j].toString().contains(".txt")){
              if(!filesf[j].toString().contains("accounts")) {
                //this isnt 100%necessary just in case the master file gets moved
                //to where everything else is
                if(!filesf[j].toString().contains("_")) {
                //unnecessary for functionality just here for testing
                  System.out.println(filesf[j]);
                  // read file
                  transactionReader = new BufferedReader(new FileReader(filesf[j]));

                  String line = null;
                  while((line = transactionReader.readLine()) != null){
                  //Append contents of file to master
                  //create if does not exist
                  if(!mergedTransactions.exists()){
                    mergedTransactions.createNewFile();

                  }
                  //writing to the
                  FileWriter writer = new FileWriter(mergedTransactions.getName(), true);
                  BufferedWriter bw = new BufferedWriter(writer);
                  bw.write(line + "\n");
                  bw.close();

                    //deletion of the old transaction file
                  filesf[j].delete();

                  System.out.println(line + " written to master file");
                  }

                }
              }
            }
          }
          FileWriter writer = new FileWriter(mergedTransactions.getName(), true);
          BufferedWriter bw = new BufferedWriter(writer);
          bw.write("\n00");
          bw.close();
        }catch(IOException e){
          return false;
        }

      }catch(Exception ee){
        return false;
      }
      return true;
    }
}
